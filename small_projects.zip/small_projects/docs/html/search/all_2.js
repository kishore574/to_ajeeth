var searchData=
[
  ['main_0',['main',['../snake__ladder_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;snake_ladder.c'],['../num__conversion_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;num_conversion.c'],['../function__call_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;function_call.c']]],
  ['moveplayer_1',['movePlayer',['../snake__ladder_8c.html#addc913fe2a1a4a29b47fd9ca6d861cee',1,'snake_ladder.c']]]
];
