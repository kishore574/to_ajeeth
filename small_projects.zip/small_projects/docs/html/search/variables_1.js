var searchData=
[
  ['player1_0',['player1',['../snake__ladder_8c.html#a431f82bf003945284e9e5369aa17a3c8',1,'snake_ladder.c']]],
  ['player2_1',['player2',['../snake__ladder_8c.html#ad60e9371981a2ebf68cd1916647d89de',1,'snake_ladder.c']]]
];
