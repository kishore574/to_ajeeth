var searchData=
[
  ['reverse_5fstring_0',['reverse_string',['../num__conversion_8c.html#ac0c1c8b3324f8321a3972e0b0b95d4bf',1,'num_conversion.c']]],
  ['rolldie_1',['rollDie',['../snake__ladder_8c.html#a5b6cc97434889cef83b1f6afc60cf89b',1,'snake_ladder.c']]]
];
