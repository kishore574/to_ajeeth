var searchData=
[
  ['global_5fvar_0',['global_var',['../num__conversion_8c.html#a9211899aa9882cc0ed5fe7926921a294',1,'global_var:&#160;num_conversion.c'],['../function__call_8c.html#a9211899aa9882cc0ed5fe7926921a294',1,'global_var:&#160;function_call.c']]]
];
