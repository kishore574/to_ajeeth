


// Function declarations

int global_var = 0; // Global variable

void function1();
void function2();
void function3();
void function4();
void function5();
void function6();
void function7();
void function8();
void function9();
void function10();

int main() {
    function1();
    return 0;
}

void function1() {
    int var1 = 10, var2 = 20;
    global_var++;
    function2();
}

void function2() {
    int var1 = 30, var2 = 40;
    global_var++;
    function3();
}

void function3() {
    int var1 = 50, var2 = 60;
    global_var++;
    function4();
}

void function4() {
    int var1 = 70, var2 = 80;
    global_var++;
    function5();
}

void function5() {
    int var1 = 90, var2 = 100;
    global_var++;
    function6();
}

void function6() {
    int var1 = 110, var2 = 120;
    global_var++;
    function7();
}

void function7() {
    int var1 = 130, var2 = 140;
    global_var++;
    function8();
}

void function8() {
    int var1 = 150, var2 = 160;
    global_var++;
    function9();
}

void function9() {
    int var1 = 170, var2 = 180;
    global_var++;
    function10();
}

void function10() {
    int var1 = 190, var2 = 200;
    global_var++;
}


